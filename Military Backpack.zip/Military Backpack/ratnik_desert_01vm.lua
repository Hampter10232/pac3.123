if SERVER then
	AddCSLuaFile()
end

player_manager.AddValidHands( "ratnik_desert_01","models/wap/russianfederation/ratnik_desert_01vm.mdl", 0, "00" )

hook.Add("PreDrawPlayerHands", "ratnik_desert_01_hands", function(hands, vm, ply, wpn)
    if IsValid(hands) 
	and hands:GetModel() == "models/wap/russianfederation/ratnik_desert_01vm.mdl"
	then
		hands:SetSkin(ply:GetSkin())
        hands:SetBodygroup(0, (ply:GetBodygroup(1)) )
        hands:SetBodygroup(1, (ply:GetBodygroup(2)) )
    end
end)
