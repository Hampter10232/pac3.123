if SERVER then
	AddCSLuaFile()
end
player_manager.AddValidModel ("ratnik_desert_01","models/wap/russianfederation/ratnik_desert_01.mdl")
